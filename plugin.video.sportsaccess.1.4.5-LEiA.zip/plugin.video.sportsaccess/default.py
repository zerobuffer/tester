import urllib.request, re, os,urllib, time
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, xbmcvfs
import json



AddonID = "plugin.video.sportsaccess"
artpath = xbmcvfs.translatePath(os.path.join('special://home/addons/' + AddonID + '/resources/'))
ADDON = xbmcaddon.Addon(id='plugin.video.sportsaccess')
selfAddon = xbmcaddon.Addon(id=AddonID)
prettyName = 'SportsAccess'
fanart = xbmcvfs.translatePath(os.path.join('special://home/addons/' + AddonID, 'fanart.jpg'))
icon = xbmcvfs.translatePath(os.path.join('special://home/addons/' + AddonID, 'icon.jpg'))
art = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.sportsaccess/resources/art', ''))
datapath = xbmcvfs.translatePath(selfAddon.getAddonInfo('profile'))
UpdatePath = os.path.join(datapath, 'Update','update.json')
UpdateDir = os.path.join(datapath, 'Update')
if not os.path.exists(UpdateDir):
    try:
        os.makedirs(UpdateDir)
    except:
        pass

# Default settings for schedule




loginUrl = 'https://auth.sportsaccess.se/token/'



user = selfAddon.getSetting('skyusername')
passw = selfAddon.getSetting('skypassword')


def uniq_id(delay=1):
    import hashlib
    mac_addr = __get_mac_address(delay=delay)
    if ':' in mac_addr and delay == 2:
        return hashlib.sha256(str(mac_addr).encode()).digest()
    else:
        return hashlib.sha256('UnsafeStaticSecret'.encode()).digest()


def __get_mac_address(delay=1):
    mac_addr = xbmc.getInfoLabel('Network.MacAddress')
    i = 0
    while ':' not in mac_addr and i < 3:
        i += 1
        time.sleep(delay)
        mac_addr = xbmc.getInfoLabel('Network.MacAddress')
    return mac_addr

def setFile(path,content='',force=False):
    from Cryptodome import Random
    from Cryptodome.Cipher import AES
    from Cryptodome.Util import Padding
    import base64
    if os.path.exists(path) and not force:
        return False
    else:
        try:
            if isinstance(content, str):
                content = content.encode('utf-8')
            crypt_key = uniq_id()
            raw = bytes(Padding.pad(data_to_pad=content, block_size=32))
            iv = Random.new().read(AES.block_size)
            cipher = AES.new(crypt_key, AES.MODE_CBC, iv)
            ciphertext= base64.b64encode(iv + cipher.encrypt(raw))
            file_out =open(path,'wb')
            file_out.write(ciphertext)
            file_out.close()
            return True
        except:
            raise
    return False


def getFile(path,default = None):
    from Cryptodome.Cipher import AES
    from Cryptodome.Util import Padding
    import base64
    content = default
    if os.path.exists(path):
        try:
            crypt_key = uniq_id()
            file_in = open(path, "rb")
            ciphertext = file_in.read()
            enc = base64.b64decode(ciphertext)
            iv = enc[:AES.block_size]
            cipher = AES.new(crypt_key, AES.MODE_CBC, iv)
            content = Padding.unpad(
                    padded_data=cipher.decrypt(enc[AES.block_size:]),
                    block_size=32).decode('utf-8')
        except: pass
        if not content: content = default
    return content


def OPENURL(url,headers=False):
    try:
        req = urllib.request.Request(url)
        if headers:            
            req.add_header('User-Agent',headers['User-Agent'])
            req.add_header('Referer', headers['Referer'])
            req.add_header('Accept', headers['Accept'])
        else:
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib.request.urlopen(req)
        onetime=response.read()
        response.close()
        onetime=onetime.decode('ascii')
        return onetime
    except:
        xbmc.executebuiltin("Notification(Sorry!,Source Website is Down,3000,"+artpath + 'empty.png'+")")
        link ="Sorry, the website is down at the moment."
        return link

def getNewCookie():
    user = selfAddon.getSetting('skyusername')
    passw = selfAddon.getSetting('skypassword')
    AuthUrl = loginUrl+user.replace(' ','%20')+'/'+passw.replace(' ','%20')
    jsonRaw=OPENURL(AuthUrl)
    if 'website is down' in jsonRaw:
        webPopup(jsonRaw)
    else:
        jsonObject = json.loads(jsonRaw)
        try:error=jsonObject['error']
        except: error=''
        if error:
            if os.path.exists(UpdatePath):
                os.remove(UpdatePath)
                Fresh()
            loginPopup("Error - "+jsonObject["error"]+"\nIncorrect password entered or invalid/expired account.")
            
        else:
            return jsonObject
    
def webPopup(message=None):
    dialog = xbmcgui.Dialog()
    dialog.ok('[COLOR red]SportsAccess[/COLOR]', message)

def loginPopup(message=None):
    dialog = xbmcgui.Dialog()
    additional = 'or register if you don have an account at sportsaccess.se'
    if message:
        additional = message
    ret = dialog.yesno('[COLOR red]SportsAccess[/COLOR]', 'Please set your SportsAccess credentials \n'+additional, 'Cancel', 'Login')
    if ret == 1:
        keyb = xbmc.Keyboard('', 'Enter Username')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText()
            username = search
            keyb = xbmc.Keyboard('', 'Enter Password:')
            keyb.setHiddenInput(True)
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText()
                password = search
                selfAddon.setSetting('skyusername', username)
                selfAddon.setSetting('skypassword', password)
    else:
        quit()

if user == '' or passw == '':
    loginPopup()



def Fresh():
    xbmc.executebuiltin("Container.Refresh")

def MAINSA():
    
    localDnT=round(time.time())
    #xbmc.log("xxx+https" + str(getNewCookie()), xbmc.LOGINFO)
    scheduleCategoryValue=selfAddon.getSetting('scheduleCategory')
    scheduleCategoryName=selfAddon.getSetting('scheduleCategoryName')
    if os.path.exists(UpdatePath):
        scheduleHtml=getFile(UpdatePath,'')        
        try:
            import threading
            threading.Thread(target=getNewCookie).start()
            SjsonObject = json.loads(scheduleHtml)
        except: os.remove(UpdatePath)
    if not os.path.exists(UpdatePath) or os.stat(UpdatePath).st_mtime + 1800 < time.time():
        jsonObject=getNewCookie()
        token= jsonObject['token']
        tag= jsonObject['tag']
        requestUrl = 'https://schedule.sportsaccess.se/api/full_schedule?token='+token+'&tag='+tag
        scheduleHtml=OPENURL(requestUrl)
        try:
            SjsonObject = json.loads(scheduleHtml)
            setFile(UpdatePath,str(scheduleHtml),True)
        except: pass
    addLink2('[I][COLOR red]Refresh Links[/COLOR][/I]  (Click Here if Vidoes are not playing)', 'url', 555,artpath + 'reload.png',fanart,'')
    addDir('[COLOR orange]All Channels[/COLOR] (Click Here)','f', 477, artpath + 'tv.png')
    addDir('[COLOR orange]Full Schedule/Upcoming Events[/COLOR] (Click Here)','f', 562, artpath + 'schedule.png')
    addDir('[COLOR red]Server:[/COLOR] [COLOR orange]'+str(selfAddon.getSetting('defaultServerName'))+"[/COLOR] (Click Here)",'f', 563,artpath + 'servers.png')
    addDir('[COLOR red]Category:[/COLOR] [COLOR orange]'+str(selfAddon.getSetting('scheduleCategoryName'))+'[/COLOR] (Click Here)','f', 557, artpath + 'category.png')
    #addDir('[COLOR red]Timezone:[/COLOR] '+scheduleConfig['scheduleTimezoneName']+' (Click Here)', 'f', 559, artpath + 'empty.png')
    addLink2('[COLOR red]Quality:[/COLOR] [COLOR orange]'+str(selfAddon.getSetting('scheduleQualityName'))+'[/COLOR] (Click Here)','f', 556, artpath + 'quality.png',fanart,'')    
    listItems=SjsonObject['schedule']
    catjson=SjsonObject['categories']
    for fields in sorted(listItems, key = lambda i: i['event_start']):
        name=fields['event_name']
        category=fields['category']
        ch=fields['channel_number']
        chList=SjsonObject['channels']
        chList=chList[int(ch)]['namespace']
        ch = '{0:02d}'.format(int(ch))
        timeS=fields['event_start']
        startDnT=time.localtime(int(timeS))
        timeE=fields['event_endtime']
        endDnT=time.localtime(int(timeE))
        img=fields['tv_image'].encode('utf-8')
        provider=fields['provider']
        language=fields['language']
        quality=fields['quality']
        if quality:
            equa='\nAvailable Quality: '+str(quality).replace("'","").replace("u","").replace("[","").replace("]","").replace(","," |")
        else:
            edesc=''
        event_description=fields['event_description']
        if event_description:
            edesc='\nDescription: '+event_description
        else:
            edesc=''
        event_runtime=str(fields['event_runtime'])
        catname=catjson[category-1]['name']
        if int(timeS)<= int(localDnT) and int(timeE)>= int(localDnT):
            startDnT=time.strftime("%I:%M %p", time.localtime(float(timeS)))
            endDnT=time.strftime("%I:%M %p", time.localtime(float(timeE)))
            desc=name+edesc+'\nSchedule: '+str(startDnT)+'-'+str(endDnT)+'\nRuntime: '+event_runtime+'min'+equa+'\nCategory: '+catname+'\nLang: '+language+'\nProvider: '+provider
            if str(category) == scheduleCategoryValue:                
                addLink2('[COLOR orange]CH:' + ch + '[/COLOR] '+'[COLOR blue]['+str(startDnT)+'-'+str(endDnT)+'][/COLOR] '+name, ch, 565,img,fanart,desc)
            if scheduleCategoryValue == '2':
                if str(category) == '3' or str(category) == '4':
                    addLink2('[COLOR orange]CH:' + ch + '[/COLOR] '+'[COLOR blue]['+str(startDnT)+'-'+str(endDnT)+'][/COLOR] '+name, ch, 565,img,fanart,desc)
            if scheduleCategoryValue == '17':
                if str(category) == '18' or str(category) == '19':
                    addLink2('[COLOR orange]CH:' + ch + '[/COLOR] '+'[COLOR blue]['+str(startDnT)+'-'+str(endDnT)+'][/COLOR] '+name, ch, 565,img,fanart,desc)
            if scheduleCategoryValue == 'All':
                addLink2('[COLOR orange]CH:' + ch + '[/COLOR] '+'[COLOR blue]['+str(startDnT)+'-'+str(endDnT)+'][/COLOR] '+name, ch, 565,img,fanart,desc)

    addLink2('[COLOR grey][I]For support vist sportsaccess.se and submit a ticket [/I][/COLOR]', 'url', '',artpath + 'icon.png', fanart,'')
    if selfAddon.getSetting("treatasmovies")== "true":
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
    

def FullChannel(url):
    SjsonObject=getFile(UpdatePath,'')
    SjsonObject = json.loads(SjsonObject)
    hashs=SjsonObject['hash']
    SjsonObject=SjsonObject['channels']    
    for fields in SjsonObject:
        name=fields['name']
        tv_image=fields['tv_image']
        ch=fields['number']
        chList=fields['namespace']
        chpad = '{0:02d}'.format(int(ch))
        if tv_image:
            img='https://sportsaccess.se/schedule_new/uploads/'+str(tv_image)
        else:
            img='https://sportsaccess.se/schedule_new/uploads/categories/tv_logo.png'
        addLink2('[COLOR orange]CH:' + chpad + '[/COLOR] '+name, str(ch), 565,img,fanart,'')


# -------------------------------- New functions ----------------------------------------------------------------------

def ChangeCategories(url):
    SjsonObject=getFile(UpdatePath,'')
    SjsonObject = json.loads(SjsonObject)
    SjsonObject=SjsonObject['categories']
    addLink2("All", 'All', 558, artpath + 'category.png',fanart,'')
    if SjsonObject:
        for fields in SjsonObject:
            name = fields["name"]
            imgid = fields["guide_id"]
            catid = fields["id"]
            #img='https://sportsaccess.se/player_new/images/categories/category_'+str(imgid)+'.png'
            img='https://fast-guide.smoothstreams.tv/assets/images/categories/white/'+str(imgid)+'.png'
            addLink2(name,str(catid), 558,img,fanart)
    

def SetQuality():
    dialog = xbmcgui.Dialog()
    ret = dialog.select('[B]Select Quality[/B]',['HD','HQ','Low SD'])
    if ret == -1:
        return
    elif ret == 0:
        selfAddon.setSetting('scheduleQualityName', 'HD')
        selfAddon.setSetting('scheduleQualityValue', 'q1')
    elif ret == 1:
        selfAddon.setSetting('scheduleQualityName', 'HQ')
        selfAddon.setSetting('scheduleQualityValue', 'q2')
    else:
        selfAddon.setSetting('scheduleQualityName', 'Low SD')
        selfAddon.setSetting('scheduleQualityValue', 'q3')
    xbmc.executebuiltin("Container.Refresh")

def SetCategory(name,url):
    # Need to persist to sustain it
    selfAddon.setSetting('scheduleCategory', url)
    selfAddon.setSetting('scheduleCategoryName', name)
    xbmc.executebuiltin("Action(Back)")

def ChangeTimezone():
    html = OPENURL(scheduleUrl, cookie='sportsaccess')
    html = cleanHex(html)
    partial = html.split('id="timezone">')[1]
    partial = partial.split('</select>')[0]
    matchlist = re.compile('value="([^"]+)".*>([^"]+)</').findall(partial)
    for value, name in matchlist:
        addLink2(name, value+"|"+name, 560, '',fanart,'')

def SetTimezone(url):
    parts = url.split("|")
    scheduleConfig['scheduleTimezoneValue'] = parts[0]
    scheduleConfig['scheduleTimezoneName'] = parts[1]
    # Need to persist to sustain it
    selfAddon.setSetting('scheduleTimezoneValue', parts[0])
    selfAddon.setSetting('scheduleTimezoneName', parts[1])
    xbmc.executebuiltin("Action(Back)")

def SortUpComingDate(SjsonObject):
    names=[]
    dates=[]
    SjsonObject=getFile(UpdatePath,'')
    SjsonObject = json.loads(SjsonObject)
    SjsonObject=SjsonObject['dates']
    for fields in sorted(SjsonObject):
        name = SjsonObject[fields]
        dates.append(fields)
        names.append(name)
    dialog = xbmcgui.Dialog()
    ret = dialog.select('[B]Select Date[/B]',names)
    if ret == -1:
        return
    else:
        selectedTime=dates[ret]
        selectedName=names[ret]
    selfAddon.setSetting('fullScheduleValue',str(selectedTime))
    selfAddon.setSetting('fullScheduleName',str(selectedName))
    xbmc.executebuiltin("Container.Refresh")
    
def ListUpComing(url):
    if float(selfAddon.getSetting("fullScheduleValue")) < time.time():
        selfAddon.setSetting("fullScheduleValue",str(time.time()))
        selfAddon.setSetting("fullScheduleName",'Today')

    fullScheduleName=selfAddon.getSetting('fullScheduleName')
    fullScheduleValue=selfAddon.getSetting('fullScheduleValue')
    SjsonObject=getFile(UpdatePath,'')
    SjsonObject = json.loads(SjsonObject)
    addLink2('[COLOR red]Select Date:[/COLOR] [COLOR orange]'+fullScheduleName+'[/COLOR] (Click Here)','f', 561,artpath + 'schedule.png',fanart,'')
    listItems=SjsonObject['schedule']
    catjson=SjsonObject['categories']
    for fields in sorted(listItems, key = lambda i: i['event_start']):
        name=fields['event_name']
        category=fields['category']
        ch=fields['channel_number']
        chList=SjsonObject['channels']
        chList=chList[int(ch)]['namespace']
        timeS=fields['event_start']
        timeE=fields['event_endtime']
        img=fields['tv_image']
        provider=fields['provider']
        language=fields['language']
        event_runtime=str(fields['event_runtime'])
        catname=catjson[category-1]['name']
        quality=fields['quality']
        if quality:
            equa='\nAvailable Quality: '+str(quality).replace("'","").replace("u","").replace("[","").replace("]","").replace(","," |")
        else:
            edesc=''
        event_description=fields['event_description']
        if event_description:
            edesc='\nDescription: '+event_description
        else:
            edesc=''
        event_runtime=str(fields['event_runtime'])
        catname=catjson[category-1]['name']
        schDate=time.strftime("%b %d %Y", time.localtime(int(timeS)))
        SelectedDate=time.strftime("%b %d %Y", time.localtime(float(fullScheduleValue)))
        if schDate == SelectedDate:
            startDnT=time.strftime("%I:%M %p", time.localtime(float(timeS)))
            endDnT=time.strftime("%I:%M %p", time.localtime(float(timeE)))
            desc=name+edesc+'\nSchedule: '+str(startDnT)+'-'+str(endDnT)+'\nRuntime: '+event_runtime+'min'+equa+'\nCategory: '+catname+'\nLang: '+language+'\nProvider: '+provider
            addLink2('[COLOR orange]CH:' + ch + '[/COLOR] '+'[COLOR blue]['+str(startDnT)+'-'+str(endDnT)+'][/COLOR] '+name, ch+'|'+chList+'|'+SjsonObject['hash'], 565,img,fanart,desc)



def ChangeServer(url):
    SjsonObject=getFile(UpdatePath,'')
    SjsonObject = json.loads(SjsonObject)
    SjsonObject=SjsonObject['servers']
    if SjsonObject:
        for fields in SjsonObject:
            name = fields["name"]
            servername = fields["serverName"]
            host = fields["hostname_ipv4"]
            port = fields["hls_port"]
            if 'Europe' in name:
                img='https://fast-guide.smoothstreams.tv/assets/flags/100x100/EU.png'
            elif 'Canada' in servername:
                img='https://fast-guide.smoothstreams.tv/assets/flags/100x100/CA.png'
            else:
                img='https://fast-guide.smoothstreams.tv/assets/flags/100x100/USA.png'
            addLink2(name+' - '+servername, servername+"|"+host+"|"+str(port), 564, img,fanart,'')

def SetServer(url):
    parts = url.split("|")
    name = parts[0]
    host = parts[1]
    port = parts[2]
    selfAddon.setSetting('defaultServerHost', host)
    selfAddon.setSetting('defaultServerPort', port)
    selfAddon.setSetting('defaultServerName', name)
    xbmc.executebuiltin("Action(Back)")


def PlayChannel(data, thumb, desc):
    chNumber = data
    if os.path.exists(UpdatePath):
        scheduleHtml=getFile(UpdatePath,'')        
        try:
            import threading
            threading.Thread(target=getNewCookie).start()
            SjsonObject = json.loads(scheduleHtml)
        except: os.remove(UpdatePath)
    chList=SjsonObject['channels']
    chList=chList[int(chNumber)]['namespace']
    hashs=SjsonObject['hash']
    host = selfAddon.getSetting('defaultServerHost')
    port = selfAddon.getSetting('defaultServerPort')
    chPad = '{0:02d}'.format(int(chNumber))
    qua=selfAddon.getSetting("scheduleQualityValue")
    playLink = "https://"+host+":"+port+"/"+chList+"/ch"+chPad+qua+"/playlist.m3u8?wmsAuthSign="+hashs
    PLAYLINK("CH - "+chNumber+" - "+selfAddon.getSetting("skyusername")+" - "+selfAddon.getSetting('defaultServerName'),playLink,thumb,desc)

def PLAYLINK(mname, murl, thumb, desc):
    ok = True
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    listitem=xbmcgui.ListItem(mname, offscreen = True)
    listitem.setArt({'thumb': thumb, 'fanart': fanart, 'icon': thumb})
    listitem.setInfo(type="Video", infoLabels={"Plot": description})
    playlist.add(murl.replace("usa.","usa-"), listitem)
    xbmcPlayer = xbmc.Player()
    xbmcPlayer.play(playlist)
    return ok


def addLink2(name, url, mode, iconimage, fanart, description=''):
    u = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(
        name) + "&iconimage=" + urllib.parse.quote_plus(iconimage) + "&fanart=" + urllib.parse.quote_plus(
        fanart) + "&description=" + urllib.parse.quote_plus(description)
    liz=xbmcgui.ListItem(name, offscreen = True)
    liz.setArt({'thumb': iconimage, 'fanart': fanart, 'icon': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    xbmc.log("fjdsfafj " +str(u), xbmc.LOGINFO)
    return ok


def addLink(name, url, iconimage):
    liz=xbmcgui.ListItem(name, offscreen = True)
    liz.setArt({'thumb': iconimage, 'fanart': fanart, 'icon': art + '/empty.png'})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz)




def addDir(name, url, mode, iconimage):
    u = sys.argv[0]

    u += "?url=" + urllib.parse.quote_plus(url)
    u += "&mode=" + str(mode)
    u += "&name=" + urllib.parse.quote_plus(name)
    u += "&iconimage=" + urllib.parse.quote_plus(iconimage)
    liz=xbmcgui.ListItem(name, offscreen = True)
    liz.setArt({'thumb': iconimage, 'fanart': fanart, 'icon': ''})
    liz.setInfo(type="Video", infoLabels={"Title": name})

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    
def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

params = get_params()
url = None
name = None
mode = None
iconimage = None
description = None

try:
    url = urllib.parse.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.parse.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
try:
    iconimage = urllib.parse.unquote_plus(params["iconimage"])
    iconimage = iconimage.replace(' ', '%20')
except:
    pass
try:
    description = urllib.parse.unquote_plus(params["description"])
except:
    pass

xbmc.log("Mode: " +str(mode), xbmc.LOGINFO)
xbmc.log("Name: " + str(name), xbmc.LOGINFO)
xbmc.log("Thumb: " +str(iconimage), xbmc.LOGINFO)

if mode == None or url == None or len(url) < 1:
    #import threading

    MAINSA()
elif mode == 413:
    PLAYLINK(name, url, iconimage)
elif mode == 477:
    FullChannel(url)
elif mode == 456:
    PlayStream(url, iconimage)
elif mode == 555:
    Fresh()
elif mode == 556:
    SetQuality()
elif mode == 557:
    ChangeCategories(url)
elif mode == 558:
    SetCategory(name,url)
elif mode == 559:
    ChangeTimezone()
elif mode == 560:
    SetTimezone(url)
elif mode == 561:
    SortUpComingDate(url)
elif mode == 562:
    ListUpComing(url)
elif mode == 563:
    ChangeServer(url)
elif mode == 564:
    SetServer(url)
elif mode == 565:
    PlayChannel(url, iconimage, description)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
